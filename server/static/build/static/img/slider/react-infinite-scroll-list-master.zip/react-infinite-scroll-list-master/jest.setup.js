global.requestAnimationFrame = () => {};
